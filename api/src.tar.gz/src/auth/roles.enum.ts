export enum Role {
  SUPERADMIN = "superadmin",
  PETUGAS = "petugas",
  VERIFIKATOR = "verifikator",
  VIEWER = "viewer",
}
